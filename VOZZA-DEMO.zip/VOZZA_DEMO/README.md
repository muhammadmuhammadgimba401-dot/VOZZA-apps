# VOZZA Demo — Reels + Voice First

A mobile-friendly frontend demo inspired by the screenshots: dark brown background, orange and gold accents, Stories at the top, voice-first composer, For You/Following/Trending, waveform-style voice posts, Reels, and a built-in shop.

## Included screens
- Home/social feed with sample voice posts, stories, tags, likes, comments/share/gift UI
- Reels preview with product discovery
- Create interfaces for voice, video/Reels, photo posts, stories, and text posts
- Voice effect selection UI
- Shop/product cards, product detail page, total price + delivery calculation
- Seller dashboard with a demo add-product form and sample orders
- Trust/safety page with seller transparency, price comparison, and report form
- Creator wallet/gifts/commission preview
- Profile, messages, notifications, settings/privacy UI
- Responsive mobile layout and bottom navigation

## Specifically excluded
No LocalStorage, D1, R2, Paystack, Firebase, or Supabase.

## Important limitations
This is a **frontend demo**, not a production application. Sample data is illustrative. Demo-created posts/products exist only in the current page session and disappear on refresh. File inputs only open a file picker; files are not uploaded or permanently stored. Audio/video playback, real recording/effects, authentication, user accounts, live messaging, moderation, real seller verification, inventory, checkout, payments, refunds, creator payouts, and real notifications are not connected. Real users and transactions require a backend and appropriate service integrations later.

## Open the demo
Open `index.html` in a modern browser, or upload `index.html` and `README.md` to a GitHub repository and enable GitHub Pages in Settings → Pages.
